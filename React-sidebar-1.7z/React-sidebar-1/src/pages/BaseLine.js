import React from "react";


function BaseLine() {
  return (
    <div className="baseline">
      <h3>BaseLine</h3>
    </div>
  );
}

export default BaseLine;
