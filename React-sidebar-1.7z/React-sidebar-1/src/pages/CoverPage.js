import React from "react";

function CoverPage() {
  return (
    <div className="home">
      <h3>CoverPage</h3>
    </div>
  );
}

export default CoverPage;
