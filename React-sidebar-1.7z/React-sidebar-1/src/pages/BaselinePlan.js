import React from "react";
import BaselinePlanView from "../components/BaselinePlanView/BaselinePlanView";

function BaselinePlan() {
  return (
    <div className="baselineplan">
      <BaselinePlanView />
    </div>
  );
}

export default BaselinePlan;
