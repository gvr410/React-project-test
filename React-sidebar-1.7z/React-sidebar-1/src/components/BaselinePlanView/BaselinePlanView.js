import React, { Component } from "react";

import TimeLine from "react-gantt-timeline";
import "./styles.css";
const colorsArr = ["#006ead", "#000000", "#00FF00", "#3CB371", "#FF0000"];
const config = {
  header: {
    top: {
      style: {
        background: "slategrey",
        textShadow: "0.5px 0.5px black",
        fontSize: 12,
        backgroundColor: "slategrey",
      },
    },
    middle: {
      style: {
        backgroundColor: "slategrey",
        fontSize: 9,
      },
    },
    bottom: {
      style: {
        backgroundColor: "slategrey",
        fontSize: 9,
        color: "#eff1f2",
      },
      selectedStyle: {
        backgroundColor: "slategrey",
        fontWeight: "bold",
        color: "white",
      },
    },
  },
  taskList: {
    title: {
      label: "Baseline Title",
      style: {
        fontWeight: "bold",
        backgroundColor: "#007bc0",
      },
    },
    task: {
      style: {
        backgroundColor: "#eff1f2",
        color: "black",
      },
    },
    verticalSeparator: {
      style: {
        backgroundColor: "slategrey",
      },
      grip: {
        style: {
          backgroundColor: "black",
        },
      },
    },
  },
  dataViewPort: {
    rows: {
      style: {
        backgroundColor: "#eff1f2",
        borderBottom: "solid 0.5px silver",
      },
    },
    task: {
      showLabel: false,
    },
  },
};

class BaselinePlanView extends Component {
  constructor(props) {
    super(props);

    let d1 = new Date();
    let d2 = new Date();
    d2.setDate(d2.getDate() + 5);
    let d3 = new Date();
    d3.setDate(d3.getDate() + 8);
    let d4 = new Date();
    d4.setDate(d4.getDate() + 10);

    let data = [
      {
        id: 1,
        start: d1,
        end: d2,
        name: "Demo Task 1",
        color: "#3CB371",
      },
      {
        id: 2,
        start: d1,
        end: d4,
        name: "Demo Task 2",
        color: "#3CB371",
      },
      {
        id: 3,
        start: d2,
        end: d4,
        name: "Demo Task 3",
        color: "#3CB371",
      },
      {
        id: 4,
        start: d3,
        end: d4,
        name: "Demo Task 4",
        color: "#3CB371",
      },
      {
        id: 5,
        start: d1,
        end: d2,
        name: "Demo Task 1",
        color: "#3CB371",
      },
      {
        id: 6,
        start: d1,
        end: d4,
        name: "Demo Task 2",
        color: "#fffff",
      },
      {
        id: 7,
        start: d2,
        end: d4,
        name: "Demo Task 3",
        color: "#3CB371",
      },
      {
        id: 8,
        start: d3,
        end: d4,
        name: "Demo Task 4",
        color: "#006ead",
      },
      {
        id: 9,
        start: d1,
        end: d2,
        name: "Demo Task 1",
        color: "#006ead",
      },
      {
        id: 10,
        start: d1,
        end: d4,
        name: "Demo Task 2",
        color: "#000000",
      },
      {
        id: 11,
        start: d2,
        end: d4,
        name: "Demo Task 3",
        color: "#000000",
      },
      {
        id: 12,
        start: d3,
        end: d4,
        name: "Demo Task 4",
        color: "#006ead",
      },
    ];

    let links = [
      { id: 1, start: 1, end: 2 },
      { id: 2, start: 1, end: 3 },
    ];

    this.state = {
      data: data,
      itemheight: 20,
      links: [],
      selectedItem: null,
      timelineMode: "month",
      counter: 0,
    };
  }
  genID() {
    function S4() {
      return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
    }
    return (
      S4() +
      S4() +
      "-" +
      S4() +
      "-4" +
      S4().substr(0, 3) +
      "-" +
      S4() +
      "-" +
      S4() +
      S4() +
      S4()
    ).toLowerCase();
  }
  handleDayWidth = (e) => {
    this.setState({ daysWidth: parseInt(e.target.value) });
  };

  handleItemHeight = (e) => {
    this.setState({ itemheight: parseInt(e.target.value) });
  };

  onHorizonChange = (start, end) => {
    let result = this.data.filter((item) => {
      return (
        (item.start < start && item.end > end) ||
        (item.start > start && item.start < end) ||
        (item.end > start && item.end < end)
      );
    });
    console.log("Calculating ");
    this.setState({ data: result });
  };
  createLink(start, end) {
    return {
      id: this.genID(),
      start: start.task.id,
      end: end.task.id,
      startPosition: start.position,
      endPosition: end.position,
    };
  }
  onUpdateTask = (item, props) => {
    item.start = props.start;
    item.end = props.end;
    this.setState({ data: [...this.state.data] });
  };
  onCreateLink = (item) => {
    let newLink = this.createLink(item.start, item.end);
    this.setState({ links: [...this.state.links, newLink] });
  };
  onSelectItem = (item) => {
    console.log(`Select Item ${item.name}`);
    this.setState({ selectedItem: item });
    var colorNum = this.state.counter >= 5 ? 0 : this.state.counter;
    //alert(`Select Item ${item.name}`);
    const elementsIndex = this.state.data.findIndex(
      (element) => element.id == item.id
    );
    let newArray = [...this.state.data];
    newArray[elementsIndex] = {
      ...newArray[elementsIndex],
      color: colorsArr[colorNum],
    };
    this.setState({
      data: newArray,
      counter: colorNum + 1,
    });
  };

  render() {
    return (
      <div className="app-container">
        <h3>Baseline Plan Overview</h3>
        <div className="time-line-container">
          <TimeLine
            data={this.state.data}
            links={this.state.links}
            config={config}
            onUpdateTask={this.onUpdateTask}
            onCreateLink={this.onCreateLink}
            onSelectItem={this.onSelectItem}
            selectedItem={this.state.selectedItem}
            onHorizonChange={this.onHorizonChange}
            mode={this.state.timelineMode}
          />
        </div>
      </div>
    );
  }
}
export default BaselinePlanView;
