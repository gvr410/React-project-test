function Profile() {
  return (
    <header>
      <h1>Profile</h1>
    </header>
  );
}

export default Profile;
