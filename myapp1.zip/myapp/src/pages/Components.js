function Components() {
  return (
    <header>
      <h1>Components</h1>
    </header>
  );
}

export default Components;
