function NotFound() {
  return (
    <header>
      <h1>Not Found</h1>
    </header>
  );
}

export default NotFound;
