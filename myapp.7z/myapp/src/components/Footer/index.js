import styled from "styled-components";
import Twitter from "../../assets/twitter-square-brands.svg";
import Instagram from "../../assets/instagram-square-brands.svg";
import Gmail from "../../assets/envelope-open-solid.svg";

const FOOTER = styled.footer`
  font-size: 1rem;
  display: flex;
  padding: 10px;
  position: fixed;
  left: 0;
  color: black;
  bottom: 0;
  height: 10px;
  width: 100%;
  align-items: center;
  justify-content: space-between;
  @media only Screen and (max-width: 48em) {
    flex-direction: column;
    align-items: center;
    div {
      &:first-child {
        margin-bottom: 1rem;
      }
    }
  }
`;

const RightText = styled.div`
  display: flex;
  align-items: center;
  img {
    width: 1.5rem;
    height: 1.5rem;
    margin-left: 1rem;
    filter: invert(100%);
    transition: all 0.2s ease-in-out;
  }
  a {
    &:hover {
      img {
        transform: scale(1.5);
        filter: invert(50%) sepia(100%) saturate(500%) hue-rotate(216deg)
          brightness(100%) contrast(97%);
      }
    }
  }
`;
const LeftText = styled.div`
  text-align: left;
`;
const Footer = () => {
  var d = new Date();
  var currentYear = d.getFullYear();
  return (
    <>
      <FOOTER>
        <LeftText>
          <small>
            &copy; Robert Bosch {`${currentYear}`}, all rights reserved.
          </small>
        </LeftText>
        <RightText>
          <small> We look forward to your inquiry</small>
          <a href="https://www.twitter.com/BoschGlobal">
            <img src={Twitter} alt="Twitter" />
          </a>
          &nbsp;
          <a href="https://www.twitter.com/BoschGlobal">
            <img src={Instagram} alt="Instagram" />
          </a>
          &nbsp;
          <a href="mailto:support@in.bosch.com?subject=Configuration Management Support">
            <img src={Gmail} alt="Mail" />
          </a>
        </RightText>
      </FOOTER>
    </>
  );
};

export default Footer;

//© 2021 by CodeBucks. Design by @CodeBucks.
