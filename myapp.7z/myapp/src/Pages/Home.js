//This is home page, It will contains all the sections require in this page.

//Import all the require sections here
import { Switch, Route, BrowserRouter, Link } from "react-router-dom";
import HeroSection from "../Sections/Hero/index";
import About from "../Sections/About/index";
import Contact from "../Sections/Contact/index";

import styled from "styled-components";

const Container = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  /* position: relative; */
`;

const Home = () => {
  return (
    <>
      <Container>
        <HeroSection />
        {/* <About /> */}
        {/* <Services /> */}
        {/* <Testimonials /> */}
        {/* <Contact /> */}

        <BrowserRouter>
          <h1>React Router Example</h1>
          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/about">About</Link>
            </li>
            <li>
              <Link to="/contact">Contact</Link>
            </li>
          </ul>

          <Switch>
            <Route exact path="/">
              <Home />
            </Route>

            <Route path="/about">
              <About />
            </Route>

            <Route path="/service">
              <About />
            </Route>

            <Route path="/contact">
              <Contact />
            </Route>
          </Switch>
        </BrowserRouter>
      </Container>
    </>
  );
};

export default Home;
