import React from "react";
import App from "../demo/pages/App";

function BaselinePlan() {
  return (
    <div className="baselineplan">
      <App />
    </div>
  );
}

export default BaselinePlan;
