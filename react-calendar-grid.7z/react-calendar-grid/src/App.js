import "./App.css";
import NavBar from "./components/NavBar";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import CoverPage from "./pages/CoverPage";
import BaseLine from "./pages/BaseLine";
import BaselinePlan from "./pages/BaselinePlan";
function App() {
  return (
    <div>
      <Router>
        <NavBar />
        <Switch>
          <Route path="/" exact component={CoverPage} />
          <Route path="/baseline" component={BaseLine} />
          <Route path="/baselineplan" component={BaselinePlan} />
        </Switch>
      </Router>
    </div>
  );
}

export default App;
