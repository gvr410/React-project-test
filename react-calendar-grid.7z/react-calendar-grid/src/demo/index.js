import React from 'react';
import ReactDOM from 'react-dom';
import App from 'pages/App';

var element = document.getElementById('react-container');
ReactDOM.render(<App />, document.getElementById('react-container'));
